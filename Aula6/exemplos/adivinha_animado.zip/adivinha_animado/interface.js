function Interface(id){
    this.id = id;
    this.elemento = document.getElementById(this.id);
    return this;
}


function Animado(){
    this.interval = undefined;
    this.angulo = 0;
    var self = this;
    this.anima = function(){
        self.interval  = window.setInterval(function(){
            self.elemento.setAttribute("style", "transform: rotateZ("+self.angulo+"deg)");
            self.angulo++;
        }, 10);
    }
}

function CaixaTexto(id){
    Interface.call(this, id);
    Animado.call(this);
    var self = this;
    this.evento_digitou = function(callback){
        self.elemento.addEventListener("change", callback);
    };
    this.getTexto = function(){
        return self.elemento.value;
    };
    this.seleciona = function(){
        self.elemento.select();
    }
    
    this.setTexto = function(texto){
        self.elemento.value = texto;
    };
}

function Display(id){
    Interface.call(this, id);
    Animado.call(this);
    var self = this;
    this.setTexto = function(text){
        self.elemento.innerText = text;
    };
}

function Botao(id){
    Interface.call(this, id);
    var self = this;
    this.evento_clicou = function(callback){
        self.elemento.addEventListener("click", callback);
    };
}

module.exports = {
    Interface: Interface,
    CaixaTexto: CaixaTexto,
    Botao: Botao,
    Display: Display
}