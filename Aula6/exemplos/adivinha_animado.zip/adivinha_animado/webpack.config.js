module.exports = {
    mode: 'development',
    output: {
        filename: "saida.js"
    },
    entry: './principal.js'
}