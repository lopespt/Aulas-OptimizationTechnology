var Jogo = require("./jogo.js");
var Interface = require("./interface.js");

var jogo = new Jogo();
var txtEscolha = new Interface.CaixaTexto("txtEscolha");
var btnReseta = new Interface.Botao("btnReseta");
var display = new Interface.Display("display");

function checar(){ 
    var resposta = jogo.checaValor(txtEscolha.getTexto());
    txtEscolha.seleciona();
    display.setTexto(resposta);
}

txtEscolha.evento_digitou( checar );

btnReseta.evento_clicou(function(){
    txtEscolha.setTexto("");
    display.setTexto("");
    jogo = new Jogo();
});

var btnCheca = new Interface.Botao("btnCheca");
btnCheca.evento_clicou(checar);
txtEscolha.anima();
display.anima();